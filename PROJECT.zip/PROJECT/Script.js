document.addEventListener('DOMContentLoaded', () => {
    const burgerToggle = document.querySelector('.burger-toggle');
    const navMenu = document.querySelector('.nav-menu');

    burgerToggle.addEventListener('click', () => {
        burgerToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
});
const slider = document.querySelector('.slider');
const images = document.querySelectorAll('.slider img');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');
const dotsContainer = document.querySelector('.dots-container');

let currentIndex = 0;

// Set interval for auto scroll (3000ms = 3 seconds)
let autoScroll;

// Function to start the auto scroll
function startAutoScroll() {
    autoScroll = setInterval(() => {
        nextSlide();
    }, 3000); // Change image every 3 seconds
}

// Function to stop the auto scroll
function stopAutoScroll() {
    clearInterval(autoScroll);
}

// Function to move to the next slide
function nextSlide() {
    currentIndex = (currentIndex < images.length - 1) ? currentIndex + 1 : 0;
    updateSlider();
}

// Function to create dots
function createDots() {
    images.forEach(() => {
        const dot = document.createElement('span');
        dot.classList.add('dot');
        dotsContainer.appendChild(dot);
    });
}

// Function to update the slider and dots
function updateSlider() {
    images.forEach(image => {
        image.classList.remove('active');
    });
    images[currentIndex].classList.add('active');

    const dots = document.querySelectorAll('.dot');
    dots.forEach(dot => {
        dot.classList.remove('active');
    });
    dots[currentIndex].classList.add('active');
}

prevBtn.addEventListener('click', () => {
    stopAutoScroll(); // Stop auto scroll when a button is clicked
    currentIndex = (currentIndex > 0) ? currentIndex - 1 : images.length - 1;
    updateSlider();
    startAutoScroll(); // Restart auto scroll
});

nextBtn.addEventListener('click', () => {
    stopAutoScroll(); // Stop auto scroll when a button is clicked
    nextSlide();
    startAutoScroll(); // Restart auto scroll
});

// Event listener for dots
dotsContainer.addEventListener('click', (e) => {
    if (e.target.classList.contains('dot')) {
        stopAutoScroll(); // Stop auto scroll when a dot is clicked
        const dots = Array.from(dotsContainer.children);
        currentIndex = dots.indexOf(e.target);
        updateSlider();
        startAutoScroll(); // Restart auto scroll
    }
});

createDots();
updateSlider();
startAutoScroll(); // Start the auto scroll when the page loads

// dropdown ahass
document.addEventListener('DOMContentLoaded', () => {
    // Other code for tabs and other functionalities

    const faqItem = document.querySelector('.faq-item');
    const faqContent = document.querySelector('.faq-content-dropdown');
    
    faqItem.addEventListener('click', () => {
        faqItem.classList.toggle('active');
        faqContent.classList.toggle('active');
    });
});

// Layanan
document.addEventListener('DOMContentLoaded', function() {
    const tabs = document.querySelectorAll('.tab');
    const contentSections = document.querySelectorAll('.service-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();

            // Get the ID of the content to display
            const targetTab = this.getAttribute('data-tab');

            // Remove active class from all tabs and content
            tabs.forEach(t => t.classList.remove('active'));
            contentSections.forEach(c => c.classList.remove('active'));

            // Add active class to the clicked tab
            this.classList.add('active');

            // Add active class to the corresponding content section
            document.getElementById(targetTab).classList.add('active');
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Pastikan kode lain yang mungkin ada di Script.js tetap berfungsi
    
    // Logika untuk Dropdown Pencarian
    const button = document.getElementById('searchButton');
    const formContainer = document.getElementById('searchFormContainer');

    if (button && formContainer) {
        button.addEventListener('click', function() {
            // Cek status tampilan saat ini (style.display)
            if (formContainer.style.display === 'block') {
                // Jika terlihat, sembunyikan
                formContainer.style.display = 'none';
            } else {
                // Jika tersembunyi, tampilkan
                formContainer.style.display = 'block';
                
                // Opsional: Fokuskan kursor langsung ke input teks
                const searchInput = formContainer.querySelector('input[type="text"]');
                if (searchInput) {
                    searchInput.focus();
                }
            }
        });
    }

    // (Tambahkan di sini kode JavaScript lain yang sudah Anda miliki, misalnya untuk slider atau tab layanan)

});